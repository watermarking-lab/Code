function colormse = colormse(original,unzip)
%% ����ԭʼͼ����źŹ���
A = double(original);
B = double(unzip);

%% ����MSE

[m,n] = size(A);
[m1,n1] = size(B);
if m~=m1||n~=n1
    error('ͼ���С��һ��');
end
sum=0;
for level=1:3
    msevalue = 0;
    for i = 1:m
        for j = 1:n/3
            msevalue = msevalue+(A(i,j,level)-B(i,j,level))^2;
        end
    end
    value = msevalue/(m*m);
    
sum=sum+value;
end
colormse=sum/3;
