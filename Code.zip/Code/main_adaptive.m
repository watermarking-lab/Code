% ����DFT 2*2block �̶�T����RGB�����и��ݸı�����С��������ͬʱ������ֵrmse������Ӧѡ��ƽ���Ҹı�С�Ŀ�
% host��RGB������ˮӡRGB����Ӧ���߲��ɼ���
clc;
clear all;
blocksize=2;%%���ڷֿ�ߴ�Ϊ4ʱ��ˮӡ�Ĳ��ɼ��Խϲͬʱ�޸�16�����أ������޹������������ȡˮӡ�ϲ�ߴ�Խ����������Ԫ�ؾ�Խ�ࣩ�����Ա��Ĳ��÷ֿ�ߴ�Ϊ2
M=1;
N=1;
%%��Կ��logisticӳ�������
x=0.1;
u=4;

im={'HDB\Avion.jpg','HDB\Peppers-1.jpg','HDB\TTU.jpg','HDB\Barbara.jpg','HDB\House.jpg','HDB\baboon.jpg','HDB\Lena.jpg','HDB\Sailboat.jpg'};%'H\portofino.pbm','H\bodie.ppm','H\butfish1.ppm','H\butrfly1.ppm','H\cactusfl.ppm','H\clinmill.ppm','H\colomtn.ppm','H\daisyfle.ppm','Avion.jpg','peppers.jpg','TTU.jpg','barbara.jpg','house.jpg','baboon.jpg'};%{'Avion.jpg','peppers.jpg','TTU.jpg','barbara.jpg','house.jpg','baboon.jpg'};%,'peppers.jpg','house.jpg','barbara.jpg','baboon.jpg','kid.jpg','Sailboat.jpg','anhinga.jpg','goldgate.ppm','bodie.ppm'};
Ws={'W/200100732.jpg','W/qq.jpg'};%,,'W/3073232.tif'
M=0;
imlen=length(im);
for imm=1:8%:imlen%��������ͼ�񼯺ϣ������ʵ��
    H=im{1,imm};
    Host=imread(H);
    for wsm=2 %:length(Ws)
        W=Ws{1,wsm};
        Water=imread(W);
%         for a=2.25:0.25:4
    for a=1.5
    for T=120%140 % ��������
        dirnm=strcat('adptRes4/',H(5:length(H)-4),'+',W(3:length(W)-4),'+',num2str(T)); 
        if ~exist(dirnm) 
            mkdir(dirnm);
        end
        M=M+1;% ��M��ʵ����
        rtitle(M,1:8)=[{[H(5:length(H)-4),'+',W(3:length(W)-4)]},{'T'},{'PSNR'},{'SSIM'},{'U_NC'},{'PSNR2'},{'Ƕ��ʱ��'},{'��ȡʱ��'}];
        lenw=size(Water,1)*size(Water,2)*8;
        [hm,hn,hlev]=size(Host);
% %          %ԭʼˮӡ���� �����Ӻ����γɷֲ�ˮӡlevelwatermark
% %          a1=1; b1=-1; c1=-1; d1=0; key=6;
% %         for level=1:3
% %             temp1=Water(:,:,level);
% %             afterAffine=Affine(temp1,a1,b1,c1,d1,key,0);
% %             levelwatermark(level,:)=gainlevelwatermark(afterAffine);
% % %                       afterArnold=Arnold(temp1,6,0);
% % %                       levelwatermark(level,:)=gainlevelwatermark(afterArnold);
% % % ���н��������logistic
% %         end
        %--------------------------------------------------
        %{%
        %% ˮӡlogistic����
        [m,n,l]=size(Water);
        %����500�Σ��ﵽ��ֻ���״̬
        for i=1:600
            x=u*x*(1-x);
        end
        %����һά�����������
        A=zeros(1,m*n);
        A(1)=x;
        for i=0:(m*n)*3-2
            A(i+2)=u*A(i+1)*(1-A(i+1));
        end
        %��һ������
        B=uint8(255*A);
        %ת��Ϊ��ά�����������
        Imgn=reshape(B,m,n,l);
        C=Water;
        Rod=bitxor(C,Imgn);%����������
        pic=strcat(dirnm,'\Water_logistic.jpg');
%         imwrite(Rod,pic);
%         imshow(Rod);
        for level=1:3
            temp1=Rod(:,:,level);
            levelwatermark(level,:)=gainlevelwatermark(temp1);
        end 
        %}
        %{
        %% ����ѡ��������
        T=80; T0=0.25*T; T1=0.75*T;
        for level=1:3
            pos0=1; pos1=1;
            Hostlevel=Host(:,:,level);
            for i=1:2:511
                for j=1:2:511
    %             if num0>=8192 && num1>=8192
    %                 break;
    %             end
                   
                    block=Hostlevel(i:i+1,j:j+1);
                    DC=sum(sum(block));
                    m=mod(DC,T);
                    if abs(m-T0)<abs(m-T1)
                        m0(pos0)=abs(m-T0); pos0=pos0+1;
                    else
                        m1(pos1)=abs(m-T1); pos1=pos1+1;
                    end
                end
            end
            tabulate(m0)
            tabulate(m1)
            histogram(m0)
            histogram(m1)
        end
        %}
        %% ˮӡǶ��
        [watermarkedim,embedPos,psnrval,ssimval,t1,ncval,t2,psnr2,len0,len1]=embedwT2(a,Host,T,blocksize,levelwatermark,Imgn,Water,dirnm);
        results(M,1)=T;
        results(M,2)=psnrval;
        results(M,3)=ssimval;
        results(M,4)=ncval;
        results(M,5)=psnr2;
        results(M,6)=t1;
        results(M,7)=t2;
%         results(M,6)=len0;
%         results(M,7)=len1;
        watermarked=strcat(dirnm,'\marked_',num2str(psnrval),'.bmp');%strcat('ResultImages/',H,W,'watermarked.bmp');
        imwrite(uint8(watermarkedim),watermarked);
        %}  
        
% % % % --------------------------------------------------
% %        �㷨����
        N=9;
        nc11=0;
%%      һ   JPEG
%{%
        watermarkedim=imread(watermarked);
        for Q=40   %10:10:100
            for level=1:3
                imwrite(watermarkedim(:,:,level),'temp.bmp','jpg','quality',Q);
                wb(:,:,level)=double(imread('temp.bmp'));
            end
            type=strcat('JPEG_',num2str(Q));
            [extractlevelwatermark,ber,psnrval,ncval]=extractwT(wb,Host,blocksize,type,lenw,T,Water,Imgn,levelwatermark,dirnm,embedPos);
            rtitle(M,N)={type};
            results(M,N)=ncval;
            N=N+1;
            rtitle(M,N)={type};
            results(M,N)=ber;
            N=N+1;
            nc11=nc11+ncval;
        end
%}
  
%{
% % % %      ��   JPEG2000       
        watermarkedim=imread(watermarked);
        for Q=10  %1:10
             for level=1:3
                imwrite(watermarkedim(:,:,level),'temp.bmp','jp2','compressionratio',Q);
                wb(:,:,level)=double(imread('temp.bmp'));
            end
            type=strcat('JPEG2000_',num2str(Q));
            [extractlevelwatermark,ber,psnrval,ncval]=extractwT(wb,Host,blocksize,type,lenw,T,Water,Imgn,levelwatermark,dirnm,embedPos);
            rtitle(M,N)={type};
            results(M,N)=ncval;
            N=N+1;
            rtitle(M,N)={type};
            results(M,N)=ber;
            N=N+1;
            nc11=nc11+ncval;
        end
%}
%-----------------------------------
%{%

%      ��  �������� ��dft�0.87 vs 0.98
        wa=imread(watermarked);
        for Q=1:2%0.5:0.5:2  %1:10
            wb=imnoise(wa,'salt & pepper',0.005*Q); 
            type=strcat('salt',num2str(0.005*Q));
            [extractlevelwatermark,ber,psnrval,ncval]=extractwT(wb,Host,blocksize,type,lenw,T,Water,Imgn,levelwatermark,dirnm,embedPos);
            rtitle(M,N)={type};
            results(M,N)=ncval;
            N=N+1;
            rtitle(M,N)={type};
            results(M,N)=ber;
            N=N+1;
            nc11=nc11+ncval;
        end
%}
%-----------------------------------
%{
%      ��   ��˹�������� nc0.69 ̫����
        a=imread(watermarked);
        for Q=1:2 % 1:5
            wb=imnoise(a,'gaussian',0,0.001*Q);
            type=strcat('gauss',num2str(0.001*Q));
%             [extractlevelwatermark,ber,psnrval,ncval]=extractwT(wb,Host,blocksize,type,lenw,T,Water,Imgn,levelwatermark,dirnm,tc);
            [extractlevelwatermark,ber,psnrval,ncval]=extractwT3(wb,Host,blocksize,type,lenw,T,Water,Imgn,levelwatermark,dirnm,tag);
            rtitle(M,N)={type};
            results(M,N)=ncval;
            N=N+1;
%             results{1}{N}='ber';
%             results{2}(pr,N)=ber;
%             N=N+1;
        end
%}
%-----------------------------------
%{%
%%    ��   Median filtering  3:0.95��,5��0.78��
        watermarkedim=imread(watermarked);
        for Q=3    %1 3 5
            for level=1:3
                wb(:,:,level)=medfilt2(watermarkedim(:,:,level),[Q,Q]);
            end
            type=strcat('median',num2str(Q));
            [extractlevelwatermark,ber,psnrval,ncval]=extractwT(wb,Host,blocksize,type,lenw,T,Water,Imgn,levelwatermark,dirnm,embedPos);
            rtitle(M,N)={type};
            results(M,N)=ncval;
            N=N+1;
            rtitle(M,N)={type};
            results(M,N)=ber;
            N=N+1;
            nc11=nc11+ncval;
        end
        nc11=nc11/4;
        results(M,N)=nc11;
        disp(nc11);
        %}
%-----------------------------------
 %{
%%      ��    Gaussian lowpass filter    
          %h = fspecial('gaussian', hsize, sigma) returns a rotationally symmetric Gaussian lowpass filter of size 
          %hsize with standard deviation sigma (positive). hsize can be a vector specifying the number of rows and columns in h, 
          %or it can be a scalar, in which case h is a square matrix. The default value for hsize is [3 3]; the default value for sigma is 0.5.
        watermarkedim=imread(watermarked);
        for Q=1:5 %1,3,5
            for level=1:3
                Ib=watermarkedim(:,:,level);
                f=double(Ib);
                AA=fspecial('gaussian',Q);
                X2=filter2(AA,f);
                X3=uint8(real(X2));
%                 ttttt(:,:,level)=X3;
                wb(:,:,level)=double(X3);
            end
            type=strcat('GausLow',num2str(Q));
            [extractlevelwatermark,ber,psnrval,ncval]=extractw(A,double(wb),blocksize,type,lenw,TC,lsnew,Host,Water,Imgn,levelwatermark,dirnm,tc);
            results{1}{N}=type;
            results{2}(pr,N)=ncval;
            N=N+1;
            results{1}{N}='ber';
            results{2}(pr,N)=ber;
            N=N+1;
        end
        %}
%-----------------------------------
%{ 
%%      ��    Butter  low-pass filtering 
        watermarkedim=imread(watermarked);
        for Q=1:2:3 %1:4
            for level=1:3
                Ib=watermarkedim(:,:,level);
                f=double(Ib);
                g=fft2(f);
                g=fftshift(g);
                [N1,N2]=size(g);
                d0=100;
                n1=fix(N1/2);
                n2=fix(N2/2);
                for i=1:N1
                    for j=1:N2
                        d=sqrt((i-n1)^2+(j-n2)^2);
                        h=1/(1+0.414*(d/d0)^(2*Q));
                        resultff(i,j)=h*g(i,j);
                    end
                end
                resultff=ifftshift(resultff);
                X2=ifft2(resultff);
                X3=uint8(real(X2));
                ttttt(:,:,level)=X3;
                wb(:,:,level)=double(X3);
            end
            type=strcat('ButterLow',num2str(Q));
            [extractlevelwatermark,ber,psnrval,ncval]=extractwT(wb,Host,blocksize,type,lenw,T,Water,Imgn,levelwatermark,dirnm,embedPos);
            rtitle(M,N)={type};
            results(M,N)=ncval;
            N=N+1;
            rtitle(M,N)={type};
            results(M,N)=ber;
            N=N+1;
        end
%}   
%-----------------------------------
%{ 
 %      ��     Cropping���� 
        for Q=1:2
            wb=double(imread(watermarked));
            wb(:,1:64*Q,:)=0; % Cropping attack 512/64=8;Q=1��1/8=12.5%
            %imwrite(wb,'temp.bmp');
            type=strcat('crop',num2str(Q));
            [extractlevelwatermark,ber,psnrval,ncval]=extractwT(wb,Host,blocksize,type,lenw,T,Water,Imgn,levelwatermark,dirnm,embedPos);
            rtitle(M,N)={type};
            results(M,N)=ncval;
            N=N+1;
            rtitle(M,N)={'ber'};
            results(M,N)=ber;
            N=N+1;
        end
        %}
 %{    
%%      ��      resize���� 
        a=imread(watermarked);
        for Q=2:6:8 %1:8 2*0.25
            wb=imresize(a,Q*0.25);
            imshow(wb);
            wb=double(imresize(wb,[512 512]));
            type=strcat('resize',num2str(Q*0.25));
            [extractlevelwatermark,ber,psnrval,ncval]=extractwT(wb,Host,blocksize,type,lenw,T,Water,Imgn,levelwatermark,dirnm,embedPos);
            rtitle(M,N)={type};
            results(M,N)=ncval;
            N=N+1;
            rtitle(M,N)={type};
            results(M,N)=ber;
            N=N+1;
        end
%}
    end
    end
%     M=M+1;
    end
end
% xlswrite('result5.xls',rtitle,1,'A1'); 
% xlswrite('result5.xls',result,1,'B2');
