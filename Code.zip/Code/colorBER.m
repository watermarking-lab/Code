   %     %             %BER
   function ber=colorBER(image1,image2)
        q=0;
        for level=1;3
            for i=1:8192
                if image1(level,i)~=image2(level,i)
                    q=q+1;
                end
            end
        end
        ber=q/24576;
%         disp(ber);
