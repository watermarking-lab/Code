function [cA]=getca(block)
%  [bm,bn]=size(block);
bsize=4;
 for i=1:2
     for j=1:2
         bi=i*2-1;  bj=j*2-1;
         cA(i,j)=floor(sum(sum(block(bi:bi+1,bj:bj+1)))/4);
     end
 end